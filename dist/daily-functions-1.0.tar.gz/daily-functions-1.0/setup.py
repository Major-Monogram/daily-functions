from setuptools import setup, find_packages

setup(
    name='daily-functions',
    version='1.0',
    packages=find_packages(),
    install_requires=[],
    author='Adyut Singh',
    author_email='adyutsingh567@email.com',
    description='some daily using functions in short',
    url='https://github.com/Major-Monogram/daily-functions.git',
)
